from django.shortcuts import render
from villaapp.models import tbl_userreg,tbl_villa,tbl_payment,tbl_request,tbl_agencyreg,tbl_order
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.contrib.auth import authenticate
# from django.contrib.auth import logout

# Create your views here.
def userReg(request): 
    return render(request,'userReg.html')

def register(request):
    if request.method=="POST":
        print("hellooooo")
        a=request.POST['fname']
        b=request.POST['lname']
        c=request.POST['place']
        d=request.POST['email']
        e=request.POST['phone']
        f=request.POST['uname']
        g=request.POST['pswd']
        print(a,b,c,d,e,f,g)
        q=tbl_userreg(firstname=a,lastname=b,place=c,email=d,phone=e,USERNAME=f,PASSWORD=g)
        q.save()
        data=User(username=f)
        data.set_password(g)
        data.save()
        return HttpResponse('<script>alert("successfully registered"),window.location="/userlogin";</script>')

def userlogin(request):
    if request.method == 'POST':
        u=request.POST['uname']
        v=request.POST['password']
        print(u,v)
        au=authenticate(username=u,password=v)
        request.session["user_id"]=u
        if au is not None and au.is_superuser==0:
            return render(request,"user_home.html")
        elif au is not None and au.is_superuser==1:
            return render(request,"agencyHome.html")
    return render(request,'userlogin.html')

# def agencylogin(request):
#     if request.method=='POST':
#         u=request.POST['uname']
#         v=request.POST['password']
#         au=authenticate(username=u,password=v)
#         request.session["user_id"]=u
#         if au is not None and au.is_superuser==1:
#             return render(request,"agencyHome.html")
#         elif au is not None and au.is_superuser==0:
#             return render(request,'agencyHome.html')
#         else:
#             return HttpResponse('Invalid User')
#     return render(request,'agencylogin.html')

def agencyHome(request):
    return render(request,'admin_home.html')

def index(request):
    return render(request,'index.html')

def agency(request):
    return render(request,'agency.html')

def userReg(request):
    return render(request,'userReg.html')

def villaReg(request):
    # cid=request.session['cid']
    if request.method=='POST':
        a=request.POST['cid']
        b=request.POST['vname']
        c=request.POST['location']
        d=request.POST['features']
        e=request.POST['amount']
        f=request.FILES['img']
        q=tbl_villa(category_id=a,villa_name=b,location=c,features=d,amount=e,photo=f)
        q.save()
        return HttpResponse('<script>alert("successfully registered"),window.location="/villaReg";</script>')
    return render(request,'villaReg.html')

def viewVilla(request):
    q=tbl_villa.objects.all()
    return render(request,'viewVilla.html',{'x':q})

def viewVillaA(request):
    q=tbl_villa.objects.all()
    return render(request,'viewVillaA.html',{'x':q})

def upDateA(request,id):
    q=tbl_villa.objects.get(id=id)
    if request.method=="POST":
        q.category_id=request.POST['cid']
        q.villa_name=request.POST['vname']
        q.location=request.POST['location']
        q.features=request.POST['features']
        q.amount=request.POST['amount']
        q.photo=request.POST['img']
        q.save()
        return HttpResponse('<script>alert("successfully added"),window.location="/viewVillaA";</script>')
    return render(request,'viewVillaA.html',{'y':q})
    
def deleteA(request,id):
    q=tbl_villa.objects.get(id=id)
    q.delete()
    return HttpResponse('<script>alert("successfully deleted"),window.location="/viewVillaA";</script>')

def payReg(request):
    if request.method=='POST':
        a=request.POST['request_id']
        b=request.POST['user_id']
        c=request.POST['amount']
        d=request.POST['status']
        q=tbl_villa(request_id=a,user_id=b,amount=c,status=d)
        q.save()
        return HttpResponse('<script>alert("successfully added"),window.location="/agencyHome";</script>') 
    return render(request,'payreg.html')

def viewPay(request):
    q=tbl_payment.objects.all()
    return render(request,'viewPay.html',{'x':q})

# def viewOrder(request):
#     q=tbl_request.objects.all()
#     return render(request,'viewOrder.html',{'x':q})

def user(request):
    return render(request,'user.html')

def userHome(request):
    return render(request,'userHome.html')

# def villaReg(request):
#     if request.method=='POST':
#         a=request.POST['cid']
#         b=request.POST['vname']
#         c=request.POST['location']
#         d=request.POST['features']
#         e=request.POST['amount']
#         f=request.POST['img']
#         q=tbl_villa(category_id=a,villa_name=b,location=c,features=d,amount=e,photo=f)
#         q.save()
#     return render(request,'villaReg.html')

def orderreg(request,id,price):
    uid=request.session['user_id']
    cid=id
    pr=price
    q=tbl_villa.objects.get(id=cid)
    vname=q.villa_name
    q1=tbl_order(category_id=cid,villa_name=vname,price=pr,user_id=uid,status='pending')  
    q1.save()
    return HttpResponse('<script>alert("Order success"),window.location="/userHome";</script>')

def viewOrderUser(request):
    uid=request.session['user_id']
    q=tbl_order.objects.filter(user_id=uid)
    return render(request,'viewOrderUser.html',{'x':q})

def viewOrderAgency(request):
    q=tbl_order.objects.all()
    return render(request,'viewOrderAgency.html',{'x':q})

def payReg(request,id,p):
    uid=request.session['user_id']
    rid=id
    pr=p
    if request.method=='POST':
        amt=request.POST['amount']
        q=tbl_payment(request_id=rid,user_id=uid,amount=amt,status="Paid")
        q.save()
        x=tbl_order.objects.get(id=rid)
        x.status="Paid"
        x.save()
        return HttpResponse('<script>alert("Payment Successfully"),window.location="/userHome";</script>')
    return render(request,'payReg.html',{'p':pr})


def viewPay(request):
    q=tbl_payment.objects.all()
    return render(request,'viewPay.html',{'x':q})

def order_approval(request,id):
    uid=id
    q=tbl_order.objects.get(id=uid)
    q.status="Approved"
    q.save()
    return HttpResponse('<script>alert("Successfully Approved"),window.location="/viewOrderAgency";</script>')

def order_rejection(request,id):
    uid=id
    q=tbl_order.objects.get(id=uid)
    q.status="Rejected"
    q.save()
    return HttpResponse('<script>alert("Successfully Rejected"),window.location="/viewOrderAgency";</script>')
